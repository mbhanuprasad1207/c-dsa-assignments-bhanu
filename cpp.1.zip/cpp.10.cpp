#include <iostream>

using namespace std;

int main()
{int i,a[10],sum=0;
 
cout<<"enter any ten numbers";

for(i=0;i<10;i++)
{cin>>a[i];
   
}
for(i=0;i<10;i++){
    sum=sum+a[i];
    
}

  cout<<"sum of the all ten numbers is"<<sum;  





    return 0;
}

