#include <iostream>

using namespace std;

int main()
{int x,y;
cout<<"enter any two numbers";
cin>>x>>y;
x=x*y;
y=x/y;
x=x/y;
cout<<"swap of "<<x <<"is"<<y<<"and"<<"swap of" <<y<<"is"<<x;

    return 0;
}