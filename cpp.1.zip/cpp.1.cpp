#include <iostream>

using namespace std;

int main()
{
    cout<<"Hello MySirG";

    return 0;
}