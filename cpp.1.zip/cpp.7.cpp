#include <iostream>

using namespace std;

int main()
{int x,S;
cout<<"Enter a number:";
cin>>x;
S=x*x;
cout<<"square of the given number is :"<<S;
    return 0;
}
