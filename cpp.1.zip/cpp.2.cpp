
#include <iostream>

using namespace std;

int main()
{
    cout<<"Hello"<<endl<<"MySirG";
   // cout<<"MySirG"<<endl;

    return 0;
}