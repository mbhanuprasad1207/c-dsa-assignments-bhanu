#include <iostream>

using namespace std;

int main()
{int x,y;
cout<<"enter any two numbers";
cin>>x>>y;
if(x>y){
    cout<<"greatest number is"<<x;
}
    else{
    cout<<"greatest number is"<<y;
}



    return 0;
}
