#include <iostream>

using namespace std;

int main()
{float x,y,z,A;
cout<<"Enter any three numbers:";
cin>>x>>y>>z;
A=(x+y+z)/3;
cout<<"The average of "<<x <<y <<z <<"is:"<<A;
    return 0;
}
