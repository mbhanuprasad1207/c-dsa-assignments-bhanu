#include <iostream>

using namespace std;

int main()
{float L,B,H,V;
cout<<"enter the length,breadth,height of the cubiod :";
cin>>L>>B>>H;
V=L*B*H;
cout<<"volume of the cubiod is :"<<V;

    
 

    return 0;
}
