#include <iostream>

using namespace std;

int main()
{int R;
float A;
float Pi=3.14;
  cout<<"enter the radius of the cicle:";
cin>>R;
A=2*Pi*R;
cout<<"area of the circle is:"<<A;
    
 

    return 0;
}