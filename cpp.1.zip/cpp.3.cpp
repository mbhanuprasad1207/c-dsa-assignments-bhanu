#include <iostream>

using namespace std;

int main()
{int a,b,s;
    cout<<"enter two numbers";
    cin>>a>>b;
    s=a+b;
    cout<<"sum of "<<a<< "and" <<b<< "is"<<s;
 

    return 0;
}