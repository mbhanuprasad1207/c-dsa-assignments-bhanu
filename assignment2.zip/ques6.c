#include<stdio.h>
int main()
{char a;
printf("enter any character");
scanf("%c",&a);
printf("%d is the ascii value for the entered character",a);
return 0;

}