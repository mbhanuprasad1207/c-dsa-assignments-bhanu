#include<stdio.h>
int main()
{int a,x,y,z;
int b;
float c;
char d;
double e;

a=sizeof(b);
x=sizeof(c);
y=sizeof(d);
z=sizeof(e);
printf("the size of int is %d,the size of float is %d,the size of char is %d,the size of double is %d",a,x,y,z);
return 0;
}
