#include<stdio.h>
int main()
{int n;
    printf("enter any number ");
    scanf("%d",n);

if(n%2==0)
{
    printf("the number is even number");
}
else{
    printf("the number is odd number");
}
return 0;
}