#include<stdio.h>
int main()
{float usd;
float inr;
printf("enter money in inr");
scanf("%f",&inr);
usd=(1/76.23)*inr;
printf("the value in usd is %f ",usd);
return 0;


}