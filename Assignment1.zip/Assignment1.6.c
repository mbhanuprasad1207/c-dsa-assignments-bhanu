#include <stdio.h>

int main()
{
   char a[100];
   printf("enter user name:");
   scanf("%s",a);
   printf("\"hello,%s\"",a);
   return 0;

}
