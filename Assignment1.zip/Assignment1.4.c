#include<stdio.h>
int main()
{
float r,a,pi=3.14;
printf("enter the radius");
scanf("%f",&r);
a=2*pi*r;
printf("area of  the circle is:%f",a);
return 0;
}
