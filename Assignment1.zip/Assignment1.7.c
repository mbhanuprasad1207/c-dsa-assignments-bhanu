#include<stdio.h>
int main()
{ char a[]="%d";

   printf("\"%s\"",a);
   return 0; 
}