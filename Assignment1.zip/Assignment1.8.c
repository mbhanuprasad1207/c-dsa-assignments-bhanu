#include<stdio.h>
int main()
{ 


   printf("\"\\n\"");
   return 0; 
}