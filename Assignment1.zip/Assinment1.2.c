#include<stdio.h>
int main()
{
printf("hello\nstudents");
return 0;
}