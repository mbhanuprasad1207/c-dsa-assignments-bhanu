#include<stdio.h>
int main()
{
printf("Hello students");
return 0;
}