#include<stdio.h>
int main()
{int n1,n2;
printf("Enter any two numbers");
scanf("%d %d",&n1,&n2);
if(n1==n2){
    printf("%d is same as %d\n",n1,n2);
}
else{
    printf("both are different numbers \n");
}

if(n1>n2)
{
    printf("%d is a greater number among %d and %d",n1,n1,n2);
}
else{
    printf("%d is greater among %d and %d \n",n2,n1,n2);
}

return 0;

}