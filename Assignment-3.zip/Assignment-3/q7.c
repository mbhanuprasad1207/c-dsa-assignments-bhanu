#include<stdio.h>
int main()
{int a,b,c,x;
printf("Enter the values of a,b,c");
scanf("%d %d %d",&a,&b,&c);
x=((b*b)-4*a*c);
if(x>0){
    printf("the roots are real and distinct");}
    else if(x<0){
        printf("the roots are real and imaginary");
    }
else
{
    printf("roots are real and equal");
}
return 0;
}