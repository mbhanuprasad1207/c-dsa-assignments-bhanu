#include<stdio.h>
int main()
{char ch;
printf("enter any alphabet");
scanf("%c",&ch);
if(ch>='A'&& ch<='Z'){
    printf("%c is upper case");
}
else if(ch>='a'&&ch<='z') {
    printf("%c is lower case");
}
if(ch>=0&&ch<=9){
    printf("%c is a digit");
}
else{
    printf("%c is a special character");
}
return 0;
}