#include<stdio.h>
int main()
{int n;
while(1){
printf("enter any month number");
scanf("%d",&n);
if(n==1||n==3||n==5||n==7||n==8||n==10||n==12)
printf("this month contains 31 days\n");
else if(n==4||n==6||n==9||n==11)
printf("this month contain 30 days\n");
else if(n==2)
printf("this month contain 28 days\n");
}
return 0;
}