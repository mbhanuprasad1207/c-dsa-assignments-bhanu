#include<stdio.h>
int main()
{int a;
printf("enter any number");
scanf("%d",&a);
if(a%3==0&&a%2==0)
printf("%d is divisible by both 3 and 2",a);
else
printf("%d is not divisible by 3 and 2",a);
return 0;
}