#include<stdio.h>
int main()
{int cp,sp,pp,lp;
    printf("Enter cost price and selling price of the product");
    scanf("%d %d",&cp,&sp);
    if(sp>cp){
        pp=((sp-cp)*100/cp);
        printf("profit percent is %d",pp);
    }
    else{
        lp=((sp-cp)*100/cp);
        printf("loss percent is %d",lp);
    }
return 0;
}