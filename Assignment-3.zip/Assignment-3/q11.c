#include<stdio.h>
int main()
{int t,h,e,m,s;
printf("enter the marks of each subjects out of 100");
scanf("%d %d %d %d %d",&t,&h,&e,&m,&s);
if(t>=33 && h>=33 && e>=33 && m>=33 && s>=33){
    printf("pass");
}
else{
    printf("fail");
}
return 0;
}