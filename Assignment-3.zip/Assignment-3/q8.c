#include<stdio.h>
int main()
{int n;
printf("enter a year");
scanf("%d",&n);
if(n%4==0){
    printf("the entered year is leap year\n ");
}
else{
    printf(" the entered year is not a leap year");
}
return 0;
}