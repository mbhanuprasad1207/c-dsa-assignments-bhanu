#include<stdio.h>
int main()
{int n;
printf("enter a number");
scanf("%d",&n);
if(n%5==0)
{printf("%d is divisble of 5",n);}
else{printf("%d is not a divisible of 5",n);}
return 0;
}