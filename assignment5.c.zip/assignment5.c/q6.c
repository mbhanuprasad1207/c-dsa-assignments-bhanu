#include<stdio.h>
int main()
{int i,n;
printf("Enter a number");
scanf("%d",&n);
for(i=1;i<=n;i=2*i){
    printf("%d ",i);
}
return 0;
}