#include<stdio.h>
int main()
{int i,cubes,n;
printf("Enter a number");
scanf("%d",&n);
for(i=1;i<=n;i++){
    cubes=i*i*i;
    printf("%d ",cubes);
}
return 0;
}