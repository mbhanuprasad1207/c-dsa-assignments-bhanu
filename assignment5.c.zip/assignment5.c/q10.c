#include<stdio.h>
int main()
{int i,j,x;
printf("Enter a number to get its table");
scanf("%d",&x);
for(j=1;j<=10;j++){
    if(i=x){
    printf("%d ",i*j);
}
}
return 0;
}