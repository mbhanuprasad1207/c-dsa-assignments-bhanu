#include<stdio.h>
int main()
{int i,squares,n;
printf("Enter a number");
scanf("%d",&n);
for(i=1;i<=n;i++){
    squares=i*i;
    printf("%d ",squares);
}
return 0;
}