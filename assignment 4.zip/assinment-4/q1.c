#include<stdio.h>
int main()
{int i=1;
for(i=1;i<=5;i++){
    printf("MySirG\n");
}
return 0;
}