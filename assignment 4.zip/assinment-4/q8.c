#include<stdio.h>
int main()
{int i,squares;
for(i=1;i<=10;i++){
    squares=i*i;
printf("%d ",squares);
}
return 0;
}