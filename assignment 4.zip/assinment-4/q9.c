#include<stdio.h>
int main()
{int i,cubes;
for(i=1;i<=10;i++){
    cubes=i*i*i;
printf("%d ",cubes);
}
return 0;
}