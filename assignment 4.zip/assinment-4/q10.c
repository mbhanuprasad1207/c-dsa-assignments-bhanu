#include <stdio.h>
int main()
{int i=5,j;
for(j=1;j<=10;j++){
        printf("%d ",i*j);
}
return 0;
}